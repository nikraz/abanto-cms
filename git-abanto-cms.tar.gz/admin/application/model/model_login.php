<?php

class model_login extends Application {

    function __construct() {
        parent::__construct();
    }

    function login() {
        $user = $this->db->input($_POST['user']);
        $pass = trim(md5($_POST['pass']));
        $num = $this->db->dbArray('SELECT COUNT(*) as num, type, name, family FROM users
			WHERE active="1" AND user = "' . $user . '" AND pass="' . $pass . '" ', true);
        $data['num'] = (int) $num['num'];
        $data['type'] = $num['type'];
        $data['name'] = $num['name'];
        $data['family'] = $num['family'];

        return $data;
    }

}
