<?php
class model_checkIncludes extends Application{
	private $id;
	private $menuId;
	private $filterId;
	public function __construct(){
		parent::__construct();
		$this->id = (int)$_GET['checkStatusId'];
		$this->menuId = (int)$_GET['menuStatusId'];
		$this->filterId = (int)$_GET['filterId'];
	}
	
	public function  updateStatus(){
		if($this->checkReallyStatus() == 1){
			$this->__desactive();
		}else{
			$this->__active();
		}	
	}
	
	// ACTIVATION 
	public function __active(){
		$this->db->dbQuery("UPDATE includes SET active='1' WHERE id=".$this->id." ", true);
	}
	
	// DISACTIVATION 
	public function __desactive(){
		$this->db->dbQuery("UPDATE includes SET active='0' WHERE id=".$this->id." ", true);
	}
	
	// CHECK RELY STATUS 
	private function checkReallyStatus(){
		$res = $this->db->dbArray("SELECT active FROM includes WHERE id=".$this->id."", true);
		return (int)$res['active'];
	}
	
	/// CHECK INCLUDES 
	public function _checkMarksActive(){
		$res = $this->db->dbArray("SELECT active FROM includes WHERE title='marks'", true);
		return (int)$res['active'];
	}
	
	public function _checkSizesActive(){
		$res = $this->db->dbArray("SELECT active FROM includes WHERE title='sizes'", true);
		return (int)$res['active'];
	}
	
	public function _checkFiltersActive(){
		$res = $this->db->dbArray("SELECT active FROM includes WHERE title='filters'", true);
		return (int)$res['active'];
	}
	
	public function _checkColorsActive(){
		$res = $this->db->dbArray("SELECT active FROM includes WHERE title='colors'", true);
		return (int)$res['active'];
	}
	/////////////////////////////////////////////
	
	// UPDATE STATUS ADMIN MENU
	public function updateStatusAdminMenu(){
		$active = $this->getReallyStatusAdminMenu();
		if($active == 1){
			$this->db->dbQuery("UPDATE administratorMenu SET active='0' WHERE id=".$this->menuId." ", true);
		} else {
			$this->db->dbQuery("UPDATE administratorMenu SET active='1' WHERE id=".$this->menuId." ", true);
		}
	}
	
	private function getReallyStatusAdminMenu(){
		$res = $this->db->dbArray("SELECT active FROM administratorMenu WHERE id=".$this->menuId."", true);
		return $res['active'];
	}
	
	// UPDATE STATUS CATALOG FILTERS 
	public function updateStatusFilters(){
		$active = $this->getReallyStatusFilters();
		if($active == 1){
			$this->db->dbQuery("UPDATE filters SET active='0' WHERE id=".$this->filterId." ", true);
		} else {
			$this->db->dbQuery("UPDATE filters SET active='1' WHERE id=".$this->filterId." ", true);
		}
	}
	
	private function getReallyStatusFilters(){
		$res = $this->db->dbArray("SELECT active FROM filters WHERE id=".$this->filterId."", true);
		return $res['active'];
	}
}
?>