<h1><?php echo $title?></h1> 
<a href="<?php echo $_SERVER['HTTP_REFERER'];?>" class="button right">Назад</a>
<p>Работата с редактора е сведена до работа с MS WORD. Всички основни фукционалности работят така както в  MS WORD като подчертване на текст, центиране на текст и тн. Добавяне на снимката става чрез натискане на бутона "снимка" <span class="cke_button_image_icon" style="background-image:url(<?=PATH?>/admin/html/ckeditor/skins/office2013/icons/image.png);background-position:0 0px;background-size:16px;width: 16px;height: 16px;display: inline-block;">&nbsp;</span>. След това натисне бутона "Избор от сървър" / Browse from server. В появилия се прозорец потърсете снимката, ако не я намерите натиснете бутона "Качи" <img src="<?=PATH?>/admin/html/kcfinder/themes/oxygen/img/icons/upload.png"/></span>. Изберете снимка от компютъра си и натиснете бутона "Отвори"/Open. След това натиснете два пъти върху нея, за да я изберете и накрая натиснете бутона "ОК". </p><br />
<p>За да направим НОВ ПАРАГРАФ натискаме "ENTER" (RETURN) , ако желаем да направим нов ред натискаме "SHIFT+ENTER" (CMD + RETURN)</p><br />
<h4>НЕЗАБРАВЯЙТЕ след като направите корекции да натиснете бутона "Запиши".</h4>
<br />
<form action="?c=textPages&m=add&menu_id=<?php echo $menu_id?>" method="post">
<?php if( count($this->langs) > 1 ):?>
    <div class="tab_menu">
        <ul class="tab_menu">
            <?php foreach( $this->langs as $l):?>
                <li><?php echo $l['content']?></li>
            <?php endforeach;?>
         </ul>
    </div>
<?php endif;?>
<div style="clear:both"></div>
<div id="tab_container"><!--NEWS-->
</div>

<?php foreach( $this->langs as $l):?>
    <div class="tab_content round4">
    <p class="typetext_icon">Съдържание на страницата<span class="red">*</span></p><br/>
    <textarea name="content_<?php echo $l['title']?>" id="content_<?php echo $l['title']?>" class="ckeditor" cols="110" rows="20">
	<?php echo $edit['content_'.$l['title']]?>
    </textarea>
   </div>
<?php endforeach;?>
<br /><br />

<?php if(YOUTUBE_TEXTPAGE == "true"): ?>
<div class="form_input">
    <p class="youtubevideo_icon">Видео от YouTube (копирайте само ограденото в червено на картинката)</p><br />

    <img src="<?php echo PATH?>/html/img/youtube.jpg" alt="Видео от YouTube" />
    <div class="sing_form">
        <input name="youtube" type="text" value="<?php echo $edit['youtube']?>" />
    </div>
</div>
<?php endif;?>
        
<input name="edit_id" type="hidden" value="<?php echo $edit['id']?>" />
<input name="post_page" type="hidden" value="1" />
<input name="" type="submit" class="button" value="запиши" />
</form><br /><br />


<?php if( $edit['id'] && GALLERY_TEXTPAGE == 'true'):?>
    <br />
    <h2 id="gallery_icon">Галерия</h2>
    <p>Преди да добавите снимките натиснете бутона "Запиши" по-горе. Можете да добавите до 6 снимки на веднъж. След като натиснете бутона "Запиши снимките" ще имате възможност да добавите още 6 снимки. Можете да подредите снимките в желаната поредица чрез влачене с мишката. След като ги поредите в желаната поредица натисне бутона "Запази подребата".</p>
    <br />
    <form action="?c=textPages&m=addImages&menu_id=<?php echo $menu_id?>" method="post" enctype="multipart/form-data">
    <input name="pictures[]" type="file" /><input name="pictures[]" type="file" /><input name="pictures[]" type="file" /><br />
    <input name="pictures[]" type="file" /><input name="pictures[]" type="file" /><input name="pictures[]" type="file" />
    <br /><br />
    <input name="add_img" type="hidden" value="1" />
    <input name="" type="submit" class="button" value="запиши снимките" />
    </form>
      <p><p/><br/>
<?php endif;?>


<!-- ПОПЪЛНИНИТЕ СНИМКИ ДО МОМЕНТА-->
<?php if( !empty($images)):?>
<br />
<h3 id="added_pictures">Добавени снимки</h3>
<div id="sortableOneLevel">
<form method="post" id="form-items" action="?c=textPages&m=imgPosition&v=<?php echo $edit['id']?>&menu_id=<?php echo $menu_id?>"> 
    <ul>
    <?php foreach($images as $m):?>
    <li id="recordsArray_<?php echo $m['id']?>"  class="ui-state-default">
    	<div class="ns-row-img">
        <img src="<?php echo PATH?>/html/img/text_pages/<?php echo $edit['id']?>/thmb_<?php echo $m['img']?>"  />
        <input type="hidden" name="menu_id" value="<?php echo $m['id']?>">
            <div class="ns-actions-img">
                <a href="?c=textPages&m=deleteGalImg&v=<?php echo $m['id']?>&menu_id=<?php echo $menu_id?>" class="confirm">
                 <img src="<?php echo ADMIN?>/html/img/cross.png" alt="Изтрий">
                </a>
            </div>
        </div>
    </li>
    <?php endforeach;?>
    </ul>
    <div style="clear:both"></div>
      <p>Ако желаете можете да промените подредата на снимките като ги влачите с мишката в желаната позиция. След това натиснете бутона "Запази подребата", които ще се появи долу в дясно.</p>
    <div id="ns-footer">
      <button type="submit" class="button green small" id="btn-save-items">Запази подребата</button>
    </div>
    </form> 
  
    <div id="contentRight"></div>
</div>
<?php endif;?>