
<h1 align="center">Списък с E-mail адреси</h1>
<a href="?c=news_leter" class="button">Обратно към Бюлетин</a>
<a href="?c=news_leter&m=e_mailList" class="button">Списък с e-mail адреси</a><br /><br /><br />

<form action="?c=news_leter&m=e_mailList" method="post">
	<div class="form_input">
		<p>E-mail<span style="color:#F00"> * </span></p><br />
        <div class="sing_form">
			<input type="email" name="mail" value="<?=$edit['email']?>" required/><br>
		</div>
    </div>
    <input type="hidden" name="edit_id" value="<?=$edit['id']?>">
   	<input type="hidden" name="add" value="1" />
    <input type="submit" value="Запиши" />
</form>


<!--EXIST EMAIL-->
<hr />
<? if(!empty($list)):?>
	<? foreach($list as $l):?>
    	
        <div class="ns-row">
        	<div class="ns-title_non"><?=$l['email']?></div>
        
        	<div class="ns-url">
        		 Краен клиент: <input type="checkbox" name="siller" value="1" class="seller" id="<?=$l['id']?>"
        	    <? if($l['seller'] == 1):?>
        	    	checked="checked"
        	    <? endif;?>
        	    /> |
            
        	    Търговец: <input type="checkbox" name="siller" value="1" class="buyer" id="<?=$l['id']?>"
        	    <? if($l['buyer'] == 1):?>
        	    	checked="checked"
        	    <? endif;?>
        	    /> 
        	</div><!--END NS-URL-->
            
            <div class="ns-actions">
            	<a href="?c=news_leter&m=delete_mail&id=<?=$l['id']?>">
                	<img src="<?=ADMIN?>/html/img/cross.png" alt="Delete">
                </a>
                
                <a href="?c=news_leter&m=edit_mail&id=<?=$l['id']?>">
                	<img src="<?=ADMIN?>/html/img/edit.png" alt="Delete">
                </a>
            </div>
        
        </div>
    <? endforeach;?>
<? endif;?>
<!--END EXIST EMAIL-->


<script type="text/javascript">
$(document).ready(function() {
	$('.err, .yes').show('slow');
	
	$('.seller').click(function(){
		$('#loader').show();
		var item_id = $(this).attr("id");
		if($(this).attr('checked')) {
			var check = 1;
		} else {
			var check = 0;
		}
		
		$.ajax({
		  type: "POST",
		  url: "?c=news_leter&m=Status&v=seller",
		  data: { id: item_id, val: check },
		  success: function(data, textStatus){
			  $('#loader').hide();
		  }
		});
		
	});
	
	
	$('.buyer').click(function(){
		$('#loader').show();
		var item_id = $(this).attr("id");
		if($(this).attr('checked')) {
			var check = 1;
		} else {
			var check = 0;
		}
		
		$.ajax({
		  type: "POST",
		  url: "?c=news_leter&m=Status&v=buyer",
		  data: { id: item_id, val: check },
		  success: function(data, textStatus){
			  $('#loader').hide();
		  }
		});
	});
	
	
});
</script>