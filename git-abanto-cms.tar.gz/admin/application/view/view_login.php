<?=$err?>

<script type="text/javascript">
$(document).ready(function() {
   $('#header').hide();
   $('#admin-values').hide();
   $('#content').css({'min-height':'430px', 'width':'900px', 'margin-top':'10%', 'margin-right':'13%'});
 });
</script>


<div id="main-login">

	<div id="login-container">
    	<h1>Вход</h1>
        <form action="?c=login&m=enter" method="post">
        
		<div class="login-input">
        <h3>Потребителско име</h3>
    	<input type="text" value=""  name="user" required="required"
        onchange="checkForm();"/>
    	</div>
    
    	<div class="login-input">
        <h3>Парола</h3>
    	<input type="password" value=""  name="pass" required="required"/>
    	</div>
        
        <div class="login-input">
        	<input type="submit" value="Влез"/>
    	</div>
        </form>
    </div>
    
</div><!-- END MAIN LOGIN-->

 