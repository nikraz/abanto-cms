<?php

class map extends Application {

    public function __construct() {
        parent::__construct();
        $this->loadModel("model_map");
    }

    public function index() {
        if ($_POST['lang']) {
            $_SESSION['lang_map'] = $_POST['lang'];
        }
        //filters
        $data['filters'] = $this->model_map->getMapFilters();
        $data['types'] = $this->model_map->getMapFiltersTypes();

        $lang = $_SESSION['lang_map'];
        $map_info = $this->model_map->getMapData($lang);
        $center = $this->model_map->mapCenter();
        $data['map'] = $map_info;
        $data['center'] = $center;
        $this->loadView("map/map", $data);
    }

    public function createMarker() {
        if ($_POST['lang']) {
            $_SESSION['lang_map'] = $_POST['lang'];
        }
        $lang = $_SESSION['lang_map'];

        $this->model_map->insertMapData();
        $map_info_edit = $this->model_map->getMapDataEdit($this->uri['entire_uri']['editId']);
        $map_info = $this->model_map->getMapData($lang);
        $center = $this->model_map->mapCenter();
        $data['map'] = $map_info;
        $data['map_edit'] = $map_info_edit;
        $data['center'] = $center;
        //filters
        $data['filters'] = $this->model_map->getMapFilters();
        $data['types'] = $this->model_map->getMapFiltersTypes();



        $this->loadView("map/map", $data);
    }

    public function editMarker() {
        if ($_POST['lang']) {
            $_SESSION['lang_map'] = $_POST['lang'];
        }
        $lang = $_SESSION['lang_map'];
        $map_info_edit = $this->model_map->getMapDataEdit($this->uri['entire_uri']['editId']);
        $map_info = $this->model_map->getMapData($lang);
        $center = $this->model_map->mapCenter();
        $data['map'] = $map_info;
        $data['map_edit'] = $map_info_edit;
        $data['center'] = $center;

        if ($_POST['edit'] == 1) {
            $this->model_map->updateMapData($this->uri['entire_uri']['editId']);
        }
        $last_id = $this->edit_product_id;
        //filters
        $data['filters'] = $this->model_map->getMapFilters();
        $data['types'] = $this->model_map->getMapFiltersTypes();
        //check for existing filters on the marker
        $data['filters_marker'] = $map_info_edit[0]['filters'];

        $this->loadView('map/map_edit', $data);
    }

    public function deleteMarker() {
        $this->db->dbQuery('DELETE FROM map_data WHERE id=' . $this->uri['entire_uri']['editId'] . ' ');
        header("Location: " . $_SERVER['HTTP_REFERER']);
    }

    public function mapFilters() {
        if (isset($_POST['update_filters'])) {
            $this->model_map->createMapFilters();
        }
        $data['filters'] = $this->model_map->getMapFilters();
        $data['types'] = $this->model_map->getMapFiltersTypes();
        $this->loadView('map/view_mapFilters', $data);
    }

    public function deleteSingleFilter() {
        $id = $this->uri['entire_uri']['filter'];
        $this->model_map->deleteSingleFilter($id);
        header("Location: " . $_SERVER['HTTP_REFERER']);
    }

    public function deleteFilterType() {
        $type = $this->uri['entire_uri']['type'];
        $lang = $this->uri['entire_uri']['lang'];
        $this->model_map->deleteFilterType($type,$lang);
        header("Location: " . $_SERVER['HTTP_REFERER']);
    }

}
