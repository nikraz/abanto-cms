<?php
class checkInkludes extends Application{
	public function __construct(){
		parent::__construct();
		$this->loadModel("model_checkIncludes");
	}
	
	public function index(){
		$data['title'] = "Опции";
		$data['catalogIncludes'] = $this->getCatalogIncludes();
		$this->loadView("checkInludes/view_index", $data);
	}
	
	
	// GET ALL OPTIONS
	public function getCatalogIncludes(){
		return $this->db->dbArray("SELECT * FROM includes");
	}
	
	// UPDATE STATUS ACTIVE AND DISACTIVE
	public function updateStatus(){
		$this->model_checkIncludes->updateStatus();
	}
	
	// UPDATE STATUS ADMIN MENU
	public function updateStatusMenu(){
		$this->model_checkIncludes->updateStatusAdminMenu();
	}
	
	// UPDATE STATUS CATALOG FILTERS
	public function updateStatusFilters(){
		$this->model_checkIncludes->updateStatusFilters();
	}
}
?>