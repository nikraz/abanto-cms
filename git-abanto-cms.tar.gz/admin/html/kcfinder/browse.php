<?php

session_start();
if (!$_SESSION['login']) {

    $ip_proxy = $_SERVER['HTTP_X_FORWARDED_FOR'];

    $ip = $_SERVER['REMOTE_ADDR'];
 
    setcookie('kc_user', $ip, time() + 60 * 60 * 60 * 60 , "/");
    setcookie('kc_user_proxy', $ip_proxy, time() + 60 * 60 * 60 * 60 , "/");
    exit('Сбогом');
}
/** This file is part of KCFinder project
 *
 *      @desc Browser calling script
 *   @package KCFinder
 *   @version 2.2
 *    @author Pavel Tzonkov <pavelc@users.sourceforge.net>
 * @copyright 2010 KCFinder Project
 *   @license http://www.opensource.org/licenses/gpl-2.0.php GPLv2
 *   @license http://www.opensource.org/licenses/lgpl-2.1.php LGPLv2
 *      @link http://kcfinder.sunhater.com
 */
require "core/autoload.php";
$browser = new browser();
$browser->action();
?>