﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'de', {
	toolbarCollapse: 'Symbolleiste einklappen',
	toolbarExpand: 'Symbolleiste ausklappen',
	toolbarGroups: {
		document: 'Dokument',
		clipboard: 'Zwischenablage/Rückgängig',
		editing: 'Editieren',
		forms: 'Formularen',
		basicstyles: 'Grundstile',
		paragraph: 'Absatz',
		links: 'Links',
		insert: 'Einfügen',
		styles: 'Stile',
		colors: 'Farben',
		tools: 'Werkzeuge'
	},
	toolbars: 'Editor Symbolleisten'
} );
