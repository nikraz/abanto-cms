﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'ro', {
	find: 'Găseşte',
	findOptions: 'Find Options',
	findWhat: 'Găseşte:',
	matchCase: 'Deosebeşte majuscule de minuscule (Match case)',
	matchCyclic: 'Potrivește ciclic',
	matchWord: 'Doar cuvintele întregi',
	notFoundMsg: 'Textul specificat nu a fost găsit.',
	replace: 'Înlocuieşte',
	replaceAll: 'Înlocuieşte tot',
	replaceSuccessMsg: '%1 căutări înlocuite.',
	replaceWith: 'Înlocuieşte cu:',
	title: 'Găseşte şi înlocuieşte'
} );
