﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'hr', {
	label: 'Stil',
	panelTitle: 'Stilovi formatiranja',
	panelTitle1: 'Block stilovi',
	panelTitle2: 'Inline stilovi',
	panelTitle3: 'Object stilovi'
} );
