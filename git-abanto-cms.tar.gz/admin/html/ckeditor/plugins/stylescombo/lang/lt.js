﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'lt', {
	label: 'Stilius',
	panelTitle: 'Stilių formatavimas',
	panelTitle1: 'Blokų stiliai',
	panelTitle2: 'Vidiniai stiliai',
	panelTitle3: 'Objektų stiliai'
} );
