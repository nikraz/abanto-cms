﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'sr-latn', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Advisory naslov',
	cssClassInputLabel: 'Stylesheet klase',
	edit: 'Edit Div', // MISSING
	inlineStyleInputLabel: 'Inline Style', // MISSING
	langDirLTRLabel: 'S leva na desno (LTR)',
	langDirLabel: 'Smer jezika',
	langDirRTLLabel: 'S desna na levo (RTL)',
	languageCodeInputLabel: ' Language Code', // MISSING
	remove: 'Remove Div', // MISSING
	styleSelectLabel: 'Stil',
	title: 'Create Div Container', // MISSING
	toolbar: 'Create Div Container' // MISSING
} );
