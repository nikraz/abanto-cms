﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'eu', {
	btn_about: 'SCAYTi buruz',
	btn_dictionaries: 'Hiztegiak',
	btn_disable: 'Desgaitu SCAYT',
	btn_enable: 'Gaitu SCAYT',
	btn_langs:'Hizkuntzak',
	btn_options: 'Aukerak',
	text_title:  'Ortografia Zuzenketa Idatzi Ahala (SCAYT)'
});
