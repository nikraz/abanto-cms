﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'en', {
	border: 'Show frame border',
	noUrl: 'Please type the iframe URL',
	scrolling: 'Enable scrollbars',
	title: 'IFrame Properties',
	toolbar: 'IFrame'
} );
