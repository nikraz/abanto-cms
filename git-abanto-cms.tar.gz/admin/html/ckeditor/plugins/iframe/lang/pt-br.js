﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'pt-br', {
	border: 'Mostra borda do iframe',
	noUrl: 'Insira a URL do iframe',
	scrolling: 'Abilita scrollbars',
	title: 'Propriedade do IFrame',
	toolbar: 'IFrame'
} );
