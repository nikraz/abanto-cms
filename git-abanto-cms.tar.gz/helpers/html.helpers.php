<?php
	function checkEmail($str){
		if(!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $str)) {
			return false;
		}
		else {
			return true;
		}
	}
	
///////////////DELETE FOLDER AND FILES////////
	function deleteFolder($dir){
		system("rm -rf $dir");
	}

///////////////
	function trimBody($string, $lmt=500) {
		
		if( mb_strlen($string, "utf-8") > $lmt ){
			$string = mb_substr($string, 0, $lmt, "utf-8");
			$string = mb_substr($string, 0, mb_strrpos($string, ' '), "utf-8") . " ...";
		}
		
		return $string;
	}

////////////////	
	function cleanText($text){
		$text = str_replace('&hArr;', '', $text);
		return $text;	
	}
	
	
	//////
	function extract_unit($string, $start, $end)
	{
		$pos = stripos($string, $start);
		
		$str = substr($string, $pos);
		
		$str_two = substr($str, strlen($start));
		
		$second_pos = stripos($str_two, $end);
		
		$str_three = substr($str_two, 0, $second_pos);
		
		$unit = trim($str_three); // remove whitespaces
		
		return $unit;
	}
	
/////////////////
	function format_price($price){
		$price = preg_replace('/[^0-9,.]/', '', $price);
		$price = str_replace(',', '.', $price);
		
		if(empty($price)){
			$price = 0;
		}
		
		if(strlen(utf8_decode($price)) == 0){
			$price = 0;
		}
		return number_format($price, 2, '.', '').' '.LV;
	}
	
	////////////////
	function format_price_admin($price){
		$price = preg_replace('/[^0-9,.]/', '', $price);
		$price = str_replace(',', '.', $price);
		
		if(empty($price)){
			$price = 0;
		}
		
		if(strlen(utf8_decode($price)) == 0){
			$price = 0;
		}
		return number_format($price, 2, '.', '');
	}
	
//////////////////	
	function removeDDS($sum){
		$price = ($sum * DDS) / (100+DDS);
		$price = $sum - $price;
		return round($price, 2);
	}
	
/////////////////////
	function send_mail($email, $title, $content)
		{
			  // To send HTML mail, the Content-type header must be set
			  $headers  = 'MIME-Version: 1.0' . "\r\n";
			  $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
		
			  // Additional headers
			  $headers .= 'From: noreply@'.str_replace('http://', '', PATH) . "\r\n";
			  $headers .= 'Content-Transfer-Encoding: 7bit' . "\r\n";
		
			  $title = "=?UTF-8?B?" . base64_encode($title) . "?=";
		
			  // Mail it
			  mail($email, $title, $content, $headers);
		}
		
	function pre($string){
		echo '<pre>';
		print_r($string);
		echo '<pre>';	
	}





