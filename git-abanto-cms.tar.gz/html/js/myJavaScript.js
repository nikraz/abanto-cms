function changeTopImages() {

    var width_page = $(window).width();
    if (width_page < 1024) {
        $('#customImages').css('margin-top', '-2.8em');
        $('#customImages').css('margin-bottom', '1em');
        $('.custom_align').css('display', 'inline-block');
        $('#about').css('margin-top', 'inline-block');
    } else {
        $('#customImages').css('margin-top', '2em');
        $('#customImages').css('margin-bottom', '');
        $('.custom_align').css('display', 'block');
    }

}

function changeWrapper()
{
    var width_page = $(window).width();
    if (width_page < 1024)
    {
        $('.custom-container').hide();
        $('.custom-place').css('margin-top', '5em');
        $('.custom-place').css('margin-bottom', '-3em');
        $('#about').css('margin-top', '8em');
        $('.advantages').css('min-height', '0');
        $('#about h3').css('top', '-1.2em');
        $('.mycom-logos').css('height', '90px');
        $('#projects img').css('margin-bottom', '1em');
         
    }
    else
    {
         $('.custom-container').show();
         $('.custom-place').css('margin-top', '-3em');
         $('.custom-place').css('margin-bottom', '-15em');
         $('#about').css('margin-top', '25em');          
         $('#about h3').css('top', '-2.6em');
         $('.mycom-logos').css('height', '130');
         $('#projects img').css('margin-bottom', '0');
    }
}
changeWrapper();
changeTopImages();

$(window).on('resize', function () {
    changeTopImages();
    changeWrapper();
});

$(document).ready(function () {

    $.validator.setDefaults({
        onkeyup: false,
        ignore: "hidden",
        invalidHandler: function (form, validator) {
            var errors = validator.numberOfInvalids();
            if (errors > '1') {
                var ErrMsg = 'fields';
            }
            if (errors == '1') {
                var ErrMsg = 'field';
            }
            var ErrMsg1 = validator.errorList[0].message;
            if (errors) {
                validator.errorList[0].element.focus();
            }
        },
        messages: {
            name: 'Моля въведете вашето име !',
            email: 'Въведете коректно вашия имейл !',
            email_footer: 'Въведете коректно вашия имейл !',
            subject: 'Въведете заглавие на съобщението',
            message: 'Въведете запитване',
            textarea: 'Въведете съобщението'
        },
        rules: {
            name: {required: true, letters: true, minlength: 2, maxlength: 50},
            email: {required: true, email: true},
            email_footer: {required: true, email: true},
            subject: {required: true, minlength: 3},
            message: {required: true},
            textarea: {required: true},
        },
    });


    $("#contact-form").validate({
        submitHandler: function () {

            //$("#contactSend").attr('disabled', 'disabled');
            var product_fields = $("#contact-form").serializeArray();
            $("#contact-form").trigger('reset');

            $.ajax({type: 'POST',
                url: PATH + '/contacts/send',
                data: product_fields,
                async: false,
                success: function (msg) {
                    alert(msg);
                    location.reload();
                }
            });
        },
    });
    $("#submit").unbind('click').click(function (event) {
        event.preventDefault();
        $("#contact-form").submit();
    });


    $("#js-contact-form").validate({
        submitHandler: function () {

            //$("#contactSend").attr('disabled', 'disabled');
            var product_fields = $("#js-contact-form").serializeArray();
            $("#js-contact-form").trigger('reset');

            $.ajax({type: 'POST',
                url: PATH + '/contacts/send_footer',
                data: product_fields,
                async: false,
                success: function (msg) {
                    alert(msg);
                    location.reload();
                }
            });
        },
    });
    $("#submit-footer").unbind('click').click(function (event) {
        event.preventDefault();
        $("#js-contact-form").submit();
    });

});


var random_images = ['1.jpg', '2.jpg', '3.jpg', '4.jpg'];
$('#background-dynamic').html('<img src="'+PATH+'/html/images/' + random_images[Math.floor(Math.random() * random_images.length)]+ '"/>');
