<div class="breadCrumbs"><h1><?php echo $newsInfo['title']?></h1></div>

<div class="news shadow">
<?php if(!empty($newsInfo['img'])):?>
    <div class="single_news_img">
        <img src="<?php echo PATH.'/html/img/news/'.$newsInfo['id'].'/thmb_'.$newsInfo['img']?>" alt="<?php echo $newsInfo['title_bg']?>"  />       
    </div>
    <?php endif;?>
    <div class="news_content"><?php echo $newsInfo['content']?></div>
    
    <div style="clear:both"></div>
    
    <br /><br />
    
    <?php if($images):?>
    	<h4><?php echo GALLERY?></h4>
		<?php foreach($images as $i):?>
            <div class="gal_images">
                <a href="<?php echo PATH?>/html/img/news/<?php echo $newsInfo['id'].'/'.$i['img']?>" class="nyroModal" rel="gal" title="<?php echo $cat_name?>">
                 <img src="<?php echo PATH?>/html/img/news/<?php echo $newsInfo['id'].'/crop_'.$i['img']?>" alt="<?php echo $cat_name?>" />
                </a>
            </div>
        <?php endforeach;?>  
        <div style="clear:both"></div><br />
    <?php endif;?>
    
    <?php if(!empty($newsInfo['youtube'])):?>
    	<h4><?php echo VIDEO?></h4>
    	<iframe title="YouTube video player" width="100%" height="410"
            src="http://www.youtube.com/embed/<?php echo $newsInfo['youtube']?>" frameborder="0" >
        </iframe>
    <?php endif;?>

   <div style="clear:both"></div><br />
    <br />
    <div class="button right"><a href="<?php echo $_SERVER['HTTP_REFERER']?>"> &#9664; <?php echo BACK?></a></div>
    <div style="clear:both"></div>
</div>     
<?php if(COMENTS == true):?>
    <div class="news shadow">    
         <?php echo $this->loadModul('comments/commentsModul')?>
    </div>    
<?php endif;?>     
<div style="clear:both"></div>
