<br />
<h2>Коментари</h2>
<? foreach($comments['comments'] as $c):?>
<div class="comments round6">
	<p class="comments_name"><?=$c['guest_name']?> каза:</p>
	<?=$c['comment']?>
</div>
<? endforeach;?>

<?=$comments['pagination']?> 