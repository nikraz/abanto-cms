<div class="title"><h1><?=REGISTER?></h1></div>
<div style="clear:both"></div>


<div id="login_left">
	<h3>Вход с вашият Facebook профил</h3>
    <br />
	<?=FB_LOGIN_TEXT?>
    <br /> <br />

	<fb:login-button><?=ENTER_WITH_FACEBOOK?></fb:login-button>
	<div id="fb-root"></div>
	<script>
      window.fbAsyncInit = function() {
        FB.init({
          appId: '<?php echo $facebook->getAppID() ?>',
          cookie: true,
          xfbml: true,
          oauth: true
        });
        FB.Event.subscribe('auth.login', function(response) {
          window.location.reload();
        });
        FB.Event.subscribe('auth.logout', function(response) {
          window.location.reload();
        });
      };
      (function() {
        var e = document.createElement('script'); e.async = true;
        e.src = document.location.protocol +
          '//connect.facebook.net/en_US/all.js';
        document.getElementById('fb-root').appendChild(e);
      }());
    </script>
</div>


<div id="login_right">
    <form action="<?=PATH.$this->linkLang().'/login/checkRegistration'?>" method="post">
    <!------USER PASS---->
    <div class="login_half">
        <p><?=USERNAME?><span class="red">*</span></p>
        
        <div class="sing_form">
            <input name="user" type="text" value="<?=$user?>" />
        </div>
    </div>
    <div style="clear:both"></div>
    <div class="login_half">
        <p><?=PASS?><span class="red">*</span></p>
        
        <div class="sing_form">
            <input name="pass" type="password" value="<?=$pass?>"/>
        </div>
    </div>
    
    <div class="login_half">
        <p><?=PASS2?><span class="red">*</span></p>
        
        <div class="sing_form">
            <input name="second_pass" type="password" value="<?=$second_pass?>"/>
        </div>
    </div>
    
    
    
    <!-----FIRS NAME LAST NAME----->
    <div style="clear:both"></div>
    
    <div class="login_half">
        <p><?=NAME?><span class="red">*</span></p>
        
        <div class="sing_form">
            <input name="name" type="text" value="<?=$name?>"/>
        </div>
    </div>
    
    <div class="login_half">
        <p><?=FAMILY?><span class="red">*</span></p>
        
        <div class="sing_form">
            <input name="family" type="text" value="<?=$family?>"/>
        </div>
    </div>
    
    
    
    <!-------PHONE EMAIL--->
    <div style="clear:both"></div>
    <div class="login_half">
        <p>E-mail<span class="red">*</span></p>
        
        <div class="sing_form">
            <input name="email" type="text" value="<?=$email?>"/>
        </div>
    </div>
    
    <div class="login_half">
        <p><?=PHONE?></p>
        
        <div class="sing_form">
            <input name="phone" type="text" value="<?=$phone?>"/>
        </div>
    </div>
    
    
    <br />
    
    <input name="singup" type="hidden" value="1" />
    <input name="" type="submit" value="<?=REGISTRATION?>" class="button"/>
    </form>
</div>
