<!-- Header Carousel -->
<header id="myCarousel" class="carousel slide">
    <!-- Wrapper for slides -->
    <?php if (!empty($slide)): ?> 
        <div class="carousel-inner">
            <?php $cnt = 0; ?>
            <?php foreach ($slide as $key => $sl): ?> 
                <!--remove empty reccords form diff lngs-->
                <?php if (!empty($sl['img_' . $this->curLnag()])): ?>

                    <div class="item <?php if ($cnt == 0): ?>active<?php endif; ?>">  
                        <div class="fill size-slider" style="background-image:url('<?= PATH ?>/html/img/slide_show/<?php echo $this->curLnag() . '/' . $sl['img_' . $this->curLnag()] ?>');"></div>
                    </div>
                    <?php $cnt++; ?>
                <?php endif; ?> 
            <?php endforeach; ?>
        </div> 
    <?php endif; ?>
    <!-- Controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
        <span class="icon-prev"></span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
        <span class="icon-next"></span>
    </a>
</header>


