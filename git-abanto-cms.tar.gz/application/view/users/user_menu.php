<ul id="user_menu">
	<li><a href="<?=PATH.$this->linkLang()?>/user">Моите поръчки</a></li>
    <li><a href="<?=PATH.$this->linkLang()?>/user/address">Адрес за доставка</a></li> 
    <? if($_SESSION['user']['fb'] == 0):?>
    <li><a href="<?=PATH.$this->linkLang()?>/user/pass">Смяна на паролата</a></li>
    <? endif;?>
</ul>
<div style="clear:both"></div>
