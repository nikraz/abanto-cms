<div class="title"><h1><?=$title?></h1></div>
<div style="clear:both"></div>
<?=$err?>

<? include 'user_menu.php'; ?>


<? if( !empty($orders) ):?>
    
    <table>
    <tr class="thead">
        <td width="50px">№ </td>
        <td>Дата</td>
        <td>Важи до:</td>
        <td>Метод н плащане</td>
        <td>Основание</td>
        <td>Статус</td>
        <td>Цена</td>
    </tr>
    <? foreach($orders as $o):?>
    <tr>
        <td><?=$o['id']?></td>
        <td><?=date('d.m.Y', $o['dateAdded'])?></td>
        <td><?=date('d.m.Y', ($o['dateAdded']+1296000))?></td>
        <td><?=$o['payment']?></td>
        <td>
        
        <?=$o['payment']?>
        <? if($o['payment']=='easypay'):?>
       <strong class="green center"><p> EasyPey КОД</p></strong>
            <strong class="red center"><p><?=$o['osnovanie']?></p></strong>
        <? elseif(($o['payment']=='bank')): ?>
            <p class="center green"><strong>Основание за плащане</strong></p>
            <p class="center red"><strong>YB-<?=$o['id']?></strong></p>
        <? endif; ?>
        
        </td>
        <td>
        <? if($o['paid']==0 && $o['active']==0):?>
            <p class="center">Очаква плащане</p>
        <? endif;?>
        
        <? if($o['active']==1):?>
            <p class="green center">Поръчката е приета</p>
        <? endif;?>
        </td>
        <td><?=number_format($o['price'], 2, '.', '')?> лв.</td>
    </tr>
    <? endforeach;?>
    </table>

<? else:?> 
   <h2>Все още нямате поръчки през вашия профил.</h2>
<? endif;?>