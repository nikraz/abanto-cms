<?php
	class model_newsletter extends Application
	{
		public $email;
		
		public function __construct(){
			parent::__construct();
			$this->email = trim($_POST['email']);
		}
		
		public function subscribe(){
			$this->db->dbQuery('INSERT into newsletter(email) VALUES("'.$this->email.'")');
		}
		
		public function unsubscribe(){
			$this->db->dbQuery('DELETE FROM newsletter WHERE email = "'.$this->uri['var'].'")');
		}
		
		public function checkExistEmail(){
			$num = $this->db->dbArray('SELECT COUNT(*) as num FROM newsletter WHERE email="'.$this->email.'"', true);
			return $num['num'];
		}
	}
?>