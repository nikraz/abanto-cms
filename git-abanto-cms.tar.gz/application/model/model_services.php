<?php
	class model_services extends Application
	{
	
		public function __construct(){
			parent::__construct();;
		}
		
		public function get(){
			$data = $this->db->dbArray('SELECT content_'.$this->curLnag().' as content FROM services', true);
			return $data['content']; 
		}
		
	}
?>