<?php
	class model_videos extends Application
	{
	
		public function __construct(){
			parent::__construct();;
		}
		
//////////////////		
		public function getvideos(){
			$count = $this->db->dbArray('SELECT COUNT(*) as num FROM videos WHERE active=1 AND menu_id='.$this->page_id, true);
			$current = $this->uri['method'];
			$perpage = VIDEOS_PER_PAGE;
			$total = $count['num'];

			$this->pagination = new pagination($total, $perpage, $current, 2, 10);
			$this->pagination->createLinks(PATH.$this->linkLang().'/'.$this->uri['controller'].'/');
			
			$data['items'] = $this->db->dbArray('SELECT 
			id, img,youtube,
			content_'.$this->curLnag().' as content, 
			title_'.$this->curLnag().' as title 
			FROM videos
			WHERE active=1 
			ORDER BY myorder DESC LIMIT '.$this->pagination->_offset.','.$perpage);
			$data['pagination'] =  $this->pagination->printLinks();
			return $data; 
		}

///////////////////		
		public function getSinglevideos(){
			return $this->db->dbArray('SELECT id, img,  youtube,
			content_'.$this->curLnag().' as content, 
			title_'.$this->curLnag().' as title 
			FROM videos
			WHERE id='.$this->uri['var'], true);
		}
////////////////////
		
		
		public function getImages($id){
			return $this->db->dbArray('SELECT * FROM videos_img WHERE cat_id='.$id.' ORDER BY myorder DESC');	
		}
//////////////////////////
		public function getLastvideos($menu_id){
			$menu_id = (int)$menu_id;
			return $this->db->dbArray('SELECT * FROM videos WHERE menu_id='.$menu_id.' ORDER BY id DESC LIMIT 6');
		}

	}
?>