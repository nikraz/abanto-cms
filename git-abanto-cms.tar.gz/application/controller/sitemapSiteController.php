<?php
	class sitemapSiteController extends Application
	{
		public $url;
		function __construct(){
			parent::__construct();
			$this->loadModel('model_comments');
			$this->url = $_SERVER['REQUEST_URI'];
		}
		
		function index(){

			$this->loadView('comments/view_comments', $data, 'ajax'); 
		}


	}
?>