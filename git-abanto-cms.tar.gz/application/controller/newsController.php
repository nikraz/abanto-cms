<?php
	class news extends Application
	{
	
		/////////////////////
		public function __construct(){	
			parent::__construct();
			$this->loadModel('model_news');
		}
		
		//////////////////
		public function index(){
			$this->loadModel('model_menu');
			$pageInfo = $this->model_menu->pageInfo();
			$data['title'] =  $pageInfo['custom_title'] == "" ? $pageInfo['title'] : $pageInfo['custom_title'];
			$data['description'] =  $pageInfo['description'];
			$newsInfo = $this->model_news->getNews();
			$data['page_name'] = PATH.$this->linkLang().'/'.$this->uri['controller'];
			$data['news'] = $newsInfo['items'];
			$data['pagination'] = $newsInfo['pagination'];                      
			$this->loadView('news/view_news', $data);
		}
		
		//////////////////
		public function view(){
			$news = $this->model_news->getSingleNews();
			$data['description'] = htmlspecialchars(trimBody( strip_tags($news['content']) ));
			$data['title'] = $news['title'];
			$data['newsInfo'] = $news;
			$data['images'] = $this->model_news->getImages($news['id']);
			$this->loadView('news/view_singleNews', $data);
		}
		
	}
?>