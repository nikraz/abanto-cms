<?php

class error extends Application {

    public function __construct() {
        parent::__construct();
        $this->loadModel('model_textPages');
    }

    function index() {
        $info = $this->model_textPages->getErrorPage();         
	 $data['error_content'] = $info['content']; 
        $this->loadView('view_error', $data);
    }

}

?>