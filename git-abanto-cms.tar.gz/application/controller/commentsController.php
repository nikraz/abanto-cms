<?php
	class comments extends Application
	{
		public $url;
		function __construct(){
			parent::__construct();
			$this->loadModel('model_comments');
			$this->url = $_SERVER['REQUEST_URI'];
		}
		
		function index(){
			$this->loadView('comments/view_comments', $data, 'ajax'); 
		}


//////////////
		public function add(){
			$result = $this->model_comments->addComment();
			$data['result'] = $result;
			$this->loadView('comments/view_add', $data, 'ajax');
		}
		
/////////////////////
		public function getComments(){
			$data['comments'] = $this->model_comments->getCommetns();
			
			if(empty($data['comments'])){
				$data['rrr'] = $url;
				$this->loadView('comments/view_noComments', $data, 'ajax');
				exit;	
			}
			
			$this->loadView('comments/view_getComments', $data, 'ajax');	
		}
		
	}
?>