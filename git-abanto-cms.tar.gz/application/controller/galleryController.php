<?php

class gallery extends Application {

    function __construct() {
        parent::__construct();
        $this->loadModel('model_gallery');
    }

    function index() {
        if ($this->uri['method']) {
            $this->getCatImages();
        } else {
            $this->getCat();
        }
    }

//////////////////////
    public function getCat() {
        $this->loadModel('model_menu');
        $pageInfo = $this->model_menu->pageInfo();
        $data['title'] = $pageInfo['custom_title'] == "" ? $pageInfo['title'] : $pageInfo['custom_title'];
        $data['description'] = $pageInfo['description'];
        $gal_var = $this->db->dbArray('SELECT id FROM menu WHERE site_url="' . $this->uri['controller'] . '" and module=2');

        $category = $this->model_gallery->getCat($gal_var[0]['id']);
		//var_dump($category);
		//echo '<pre>'.print_r($category,true).'</pre>';
        foreach ($category['cats'] as $cat): 
            $arr[$cat['id']] = array(
                'id' => $cat['id'],
                'site_url' => $cat['site_url'],
                'cat' => $cat['title_' . $this->curLnag() . ''], 
                'con' => $cat['content_' . $this->curLnag() . ''], 
                'img' => $this->model_gallery->getCatImages($cat['id'])
            );
        endforeach;
		$data['pagination'] = $category['cat_pagination'];
        $data['cat'] = $arr; 
        $this->loadView('gallery/view_gallery', $data);
    }

////////////////////////	
    public function getCatImages() {
        if ($this->model_gallery->checkGallery() == false) {
            $this->getCat();
        } else {

            $data['cat_id'] = $this->model_gallery->checkGallery();
            $data['cat_name'] = $this->model_gallery->catName($data['cat_id']);
			$data['cat_content'] = $this->model_gallery->catContent($data['cat_id']);
            $data['title'] = $data['cat_name'];

            $data['img'] = $this->model_gallery->getImages($data['cat_id']);


            $this->loadView('gallery/view_images', $data);
        }
    }

}

?>