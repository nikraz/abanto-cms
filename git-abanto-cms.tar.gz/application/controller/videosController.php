<?php
	class videos extends Application
	{
	
		/////////////////////
		public function __construct(){	
			parent::__construct();
			$this->loadModel('model_videos');
		}
		
		//////////////////
		public function index(){
			$this->loadModel('model_menu');
			$pageInfo = $this->model_menu->pageInfo();
			$data['title'] =  $pageInfo['custom_title'] == "" ? $pageInfo['title'] : $pageInfo['custom_title'];
			$data['description'] =  $pageInfo['description'];
			$videosInfo = $this->model_videos->getvideos();
			$data['page_name'] = PATH.$this->linkLang().'/'.$this->uri['controller'];
			$data['videos'] = $videosInfo['items'];
			$data['pagination'] = $videosInfo['pagination'];
			$this->loadView('videos/view_videos', $data);
		}
		
		//////////////////
		public function view(){
			$videos = $this->model_videos->getSinglevideos();
			$data['description'] = htmlspecialchars(trimBody( strip_tags($videos['content']) ));
			$data['title'] = $videos['title'];
			$data['videosInfo'] = $videos;
			$data['images'] = $this->model_videos->getImages($videos['id']);
			$this->loadView('videos/view_singlevideos', $data);
		}
		
	}
?>